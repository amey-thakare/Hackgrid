---
description: The Architect — Analyze codebase and update ARCHITECTURE.md and STACK.md
---

# /map Workflow

<role>
You are a GSD codebase mapper. You analyze existing codebases to understand structure, patterns, and technical debt.

**Core responsibilities:**
- Scan project structure and identify components
- Analyze dependencies and versions
- Map data flow and integration points
- Identify technical debt and patterns
- Document findings for planning context
</role>

<objective>
Analyze the existing codebase and produce documentation that enables informed planning.

This workflow should be run BEFORE `/plan` on brownfield projects to give the planner full context.
</objective>

<context>
**No arguments required.** Operates on current project directory.

**Outputs:**
- `.gsd/ARCHITECTURE.md` — System design documentation
- `.gsd/STACK.md` — Technology inventory

**Delegation protocol:** `.agents/skills/subagent-delegation/SKILL.md`
**Subagent:** `.agents/agents/gsd-researcher.md`
</context>

<process>

## 0. Delegate the Mapping

**If `invoke_subagent` is available**, invoke `gsd-researcher` with workspace mode `share`:

```
mode: map

Write .gsd/ARCHITECTURE.md and .gsd/STACK.md.
Cite findings with file:line. Record what you could not determine.
Return the compact digest from your Return Contract — nothing else.
```

Mapping is the single most context-expensive workflow in GSD — it reads the whole project by
design. Running it inline means the codebase you just mapped is now competing for space with
the phase you wanted to plan. Delegate it, then read the artifacts only when you need them.

Skip to step 8 (Update State) once the digest comes back.

Steps 1-7 describe what the researcher does. Run them yourself only in inline mode.

---

## 1. Validate Project

Check this is a valid project:

**PowerShell:**
```powershell
# Look for common project indicators
$indicators = @(
    "package.json", "requirements.txt", "Cargo.toml", 
    "go.mod", "pom.xml", "*.csproj", "Gemfile"
)
```

**Bash:**
```bash
# Look for common project indicators
indicators=("package.json" "requirements.txt" "Cargo.toml" 
    "go.mod" "pom.xml" "*.csproj" "Gemfile")
```

Display banner:
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 GSD ► MAPPING CODEBASE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

---

## 2. Analyze Project Structure

### 2a. Directory Analysis

**PowerShell:**
```powershell
Get-ChildItem -Recurse -Directory | 
    Where-Object { $_.Name -notmatch "node_modules|\.git|__pycache__|dist|build" }
```

**Bash:**
```bash
find . -type d -not -path '*/node_modules/*' -not -path '*/.git/*' \
    -not -path '*/__pycache__/*' -not -path '*/dist/*' -not -path '*/build/*'
```

Identify:
- Source directories (`src/`, `lib/`, `app/`)
- Test directories (`tests/`, `__tests__/`, `spec/`)
- Configuration locations
- Asset directories

### 2b. Entry Points

Find main files:
**PowerShell:**
```powershell
# Example for Node.js
Get-Content "package.json" | ConvertFrom-Json | Select-Object -ExpandProperty main
```

**Bash:**
```bash
# Example for Node.js (requires jq)
cat package.json | jq -r '.main'
```

### 2c. Component Detection

Scan for common patterns:
- React components (`*.tsx`, `*.jsx`)
- API routes (`routes/`, `api/`)
- Database models (`models/`, `entities/`)
- Services (`services/`, `lib/`)
- Utilities (`utils/`, `helpers/`)

---

## 3. Analyze Dependencies

### 3a. Production Dependencies

**PowerShell:**
```powershell
# Node.js example
Get-Content "package.json" | ConvertFrom-Json | 
    Select-Object -ExpandProperty dependencies
```

**Bash:**
```bash
# Node.js example (requires jq)
cat package.json | jq '.dependencies'
```

For each dependency, note:
- Name and version
- Purpose (infer from name/usage)
- Is it actively used?

### 3b. Development Dependencies

Same for devDependencies, noting:
- Build tools
- Test frameworks
- Linters/formatters

### 3c. Outdated Packages

```bash
npm outdated
# or
pip list --outdated
```

---

## 4. Map Data Flow

### 4a. External Integrations

Search for:
**PowerShell:**
```powershell
# API calls
Select-String -Path "src/**/*" -Pattern "fetch\(|axios\.|http\."

# Database connections
Select-String -Path "**/*" -Pattern "DATABASE_URL|mongodb|postgres|mysql"

# Third-party services
Select-String -Path "**/*" -Pattern "stripe|sendgrid|twilio|aws-sdk"
```

**Bash:**
```bash
# API calls
grep -rE 'fetch\(|axios\.|http\.' src/

# Database connections
grep -rE 'DATABASE_URL|mongodb|postgres|mysql' .

# Third-party services
grep -rE 'stripe|sendgrid|twilio|aws-sdk' .
```

### 4b. Internal Flow

Trace how data moves:
- Entry point → Business logic → Data layer → Output
- Identify shared state (context, stores, singletons)

---

## 5. Identify Technical Debt

### 5a. Code Smells

Search for indicators:
**PowerShell:**
```powershell
# TODOs and FIXMEs
Select-String -Path "src/**/*" -Pattern "TODO|FIXME|HACK|XXX"

# Deprecated markers
Select-String -Path "**/*" -Pattern "@deprecated|DEPRECATED"
```

**Bash:**
```bash
# TODOs and FIXMEs
grep -rE 'TODO|FIXME|HACK|XXX' src/

# Deprecated markers
grep -rE '@deprecated|DEPRECATED' .
```

### 5b. Pattern Inconsistencies

Note where patterns differ:
- Naming conventions
- File organization
- Error handling approaches

### 5c. Missing Elements

Identify gaps:
- No tests for critical paths
- Missing error boundaries
- No input validation
- No logging/monitoring

---

## 6. Write ARCHITECTURE.md

```markdown
# Architecture

> Auto-generated by /map on {date}

## Overview

{High-level description of what this system does}

```
┌─────────────────────────────────────────┐
│              [Entry Point]              │
├─────────────────────────────────────────┤
│         [Business Logic Layer]          │
├─────────────────────────────────────────┤
│            [Data Layer]                 │
└─────────────────────────────────────────┘
```

## Components

### {Component 1}
- **Purpose:** {what it does}
- **Location:** `{path}`
- **Dependencies:** {what it imports}

### {Component 2}
...

## Data Flow

1. {Step 1}
2. {Step 2}
3. {Step 3}

## Integration Points

| Service | Type | Purpose |
|---------|------|---------|
| {name} | API | {purpose} |

## Technical Debt

- [ ] {Debt item 1}
- [ ] {Debt item 2}

## Conventions

**Naming:** {patterns observed}
**Structure:** {organization patterns}
**Testing:** {test patterns}
```

---

## 7. Write STACK.md

```markdown
# Technology Stack

> Auto-generated by /map on {date}

## Runtime

| Technology | Version | Purpose |
|------------|---------|---------|
| {runtime} | {version} | Core runtime |

## Dependencies

### Production
| Package | Version | Purpose |
|---------|---------|---------|
| {pkg} | {ver} | {purpose} |

### Development
| Package | Version | Purpose |
|---------|---------|---------|
| {pkg} | {ver} | {purpose} |

## Infrastructure

| Service | Provider | Purpose |
|---------|----------|---------|
| {service} | {provider} | {purpose} |

## Configuration

| Variable | Purpose | Location |
|----------|---------|----------|
| {var} | {purpose} | {file} |

## Outdated Packages

| Package | Current | Latest | Risk |
|---------|---------|--------|------|
| {pkg} | {cur} | {new} | {risk} |
```

---

## 8. Update State

Update `.gsd/STATE.md`:
```markdown
## Last Session Summary
Codebase mapping complete.
- {N} components identified
- {M} dependencies analyzed
- {K} technical debt items found
```

---

## 9. Commit Documentation

```bash
git add .gsd/ARCHITECTURE.md .gsd/STACK.md .gsd/STATE.md
git commit -m "docs: map existing codebase"
```

---

## 10. Offer Next Steps

</process>

<offer_next>

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 GSD ► CODEBASE MAPPED ✓
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Components: {N}
Dependencies: {M} production, {K} dev
Technical debt: {J} items

───────────────────────────────────────────────────────

▶ Next Up

/plan — create execution plans with full context

Files updated:
• .gsd/ARCHITECTURE.md
• .gsd/STACK.md

───────────────────────────────────────────────────────
```

</offer_next>

<related>
## Related

### Workflows
| Command | Relationship |
|---------|--------------|
| `/plan` | Use ARCHITECTURE.md from /map for planning context |

### Skills
| Skill | Purpose |
|-------|---------|
| `codebase-mapper` | Detailed mapping methodology |
</related>
