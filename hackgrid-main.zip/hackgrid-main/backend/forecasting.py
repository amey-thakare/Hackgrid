"""
Lightweight Forecasting & Risk Outlook Engine for FinSight Financial Firebreak.
PRD v1.1 Sec 5.2:
- Separates deterministic trend projection from LLM interpretation.
- Projects selected metrics (DSO, CCC, Working Capital Stress) over 30, 60, and 90 days when >= 3 historical periods exist.
- Explicitly labels trajectories as 'heuristic outlook / insufficient-history case' when data is insufficient (T-19).
"""

from typing import Any, Dict, List, Optional
import numpy as np
import pandas as pd


def generate_risk_outlook(df: pd.DataFrame, current_metrics: Dict[str, Any]) -> Dict[str, Any]:
    """
    Computes 30/60/90-day trajectory projections or heuristic outlooks.
    """
    has_history = len(df) >= 3
    rec = current_metrics.get("receivables_health", {})
    cf = current_metrics.get("cash_flow_efficiency", {})
    inv = current_metrics.get("inventory_efficiency", {})

    current_dso = rec.get("dso_proxy") or 45.0
    current_dio = inv.get("dio_days") or 50.0
    current_ccc = cf.get("ccc_days") or 60.0

    if not has_history:
        # PRD Constraint T-19: Insufficient history -> DO NOT fabricate precision!
        # Return labeled heuristic trajectory with missing evidence explanation
        return {
            "outlook_type": "heuristic_outlook",
            "is_defensible_forecast": False,
            "quality_label": "Heuristic Outlook (Insufficient Historical Data)",
            "missing_evidence": "Single or limited historical periods provided (< 3 periods). Time-series trend extrapolation unavailable.",
            "periods": [
                {
                    "day_horizon": 30,
                    "label": "30 Days",
                    "projected_dso": round(current_dso * 1.02, 1),
                    "projected_ccc": round(current_ccc * 1.02, 1),
                    "directional_stress": "Stable / Slightly Elevated",
                    "confidence_band": "Wide (Heuristic Estimate)",
                },
                {
                    "day_horizon": 60,
                    "label": "60 Days",
                    "projected_dso": round(current_dso * 1.04, 1),
                    "projected_ccc": round(current_ccc * 1.05, 1),
                    "directional_stress": "Elevated",
                    "confidence_band": "Wide (Heuristic Estimate)",
                },
                {
                    "day_horizon": 90,
                    "label": "90 Days",
                    "projected_dso": round(current_dso * 1.07, 1),
                    "projected_ccc": round(current_ccc * 1.08, 1),
                    "directional_stress": "High Sensitivity",
                    "confidence_band": "Wide (Heuristic Estimate)",
                },
            ],
            "methodology": "Heuristic persistence assumption with sensitivity corridor (no curve fitting manufactured).",
        }

    # Defensible Python Trend Projection
    # Extract historical DSO and CCC series
    periods_count = len(df)
    dso_history = []
    ccc_history = []

    for idx in range(periods_count):
        row = df.iloc[idx]
        rev = float(row.get("revenue", 1.0))
        ar = float(row.get("accounts_receivable", 0.0))
        cogs = float(row.get("cogs", 1.0))
        inventory = float(row.get("inventory", 0.0))
        ap = float(row.get("accounts_payable", 0.0))

        dso_i = (ar / rev) * 365.0 if rev > 0 else current_dso
        dio_i = (inventory / cogs) * 365.0 if cogs > 0 else current_dio
        dpo_i = (ap / cogs) * 365.0 if cogs > 0 else 30.0
        ccc_i = dso_i + dio_i - dpo_i

        dso_history.append(dso_i)
        ccc_history.append(ccc_i)

    # Linear trend regression over existing time points
    x = np.arange(periods_count)
    # DSO slope
    slope_dso, intercept_dso = np.polyfit(x, dso_history, 1) if periods_count >= 2 else (0.0, current_dso)
    # CCC slope
    slope_ccc, intercept_ccc = np.polyfit(x, ccc_history, 1) if periods_count >= 2 else (0.0, current_ccc)

    # Project 1, 2, and 3 steps forward (approximating 30, 60, 90 days for monthly cadence)
    dso_30 = round(max(10.0, current_dso + slope_dso * 1), 1)
    dso_60 = round(max(10.0, current_dso + slope_dso * 2), 1)
    dso_90 = round(max(10.0, current_dso + slope_dso * 3), 1)

    ccc_30 = round(current_ccc + slope_ccc * 1, 1)
    ccc_60 = round(current_ccc + slope_ccc * 2, 1)
    ccc_90 = round(current_ccc + slope_ccc * 3, 1)

    return {
        "outlook_type": "projected_forecast",
        "is_defensible_forecast": True,
        "quality_label": f"Trend Projection ({periods_count} Historical Periods)",
        "missing_evidence": None,
        "historical_periods_used": periods_count,
        "periods": [
            {
                "day_horizon": 30,
                "label": "30 Days",
                "projected_dso": dso_30,
                "projected_ccc": ccc_30,
                "directional_stress": "Elevated" if dso_30 > current_dso else "Improving",
                "confidence_band": "High (R2 Extrapolation)",
            },
            {
                "day_horizon": 60,
                "label": "60 Days",
                "projected_dso": dso_60,
                "projected_ccc": ccc_60,
                "directional_stress": "Critical" if dso_60 > current_dso * 1.15 else "Moderate",
                "confidence_band": "Moderate",
            },
            {
                "day_horizon": 90,
                "label": "90 Days",
                "projected_dso": dso_90,
                "projected_ccc": ccc_90,
                "directional_stress": "Severe Risk-Chain" if dso_90 > current_dso * 1.25 else "Stable",
                "confidence_band": "Indicative",
            },
        ],
        "methodology": "First-order time-series regression on trailing ERP observations.",
    }
