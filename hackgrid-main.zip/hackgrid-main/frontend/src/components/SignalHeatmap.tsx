import React, { useState } from 'react';
import type { MetricsSummary, SeverityLevel } from '../types/firebreak';
import { Calendar, Users, Building2, Package, TrendingUp, DollarSign, ChevronRight, AlertCircle } from 'lucide-react';

interface SignalHeatmapProps {
  metrics: MetricsSummary;
}

export const SignalHeatmap: React.FC<SignalHeatmapProps> = ({ metrics }) => {
  const [selectedSignal, setSelectedSignal] = useState<string | null>(null);

  const getSeverityBadge = (severity: SeverityLevel) => {
    switch (severity) {
      case 'critical':
        return <span className="badge badge-critical">Critical</span>;
      case 'elevated':
        return <span className="badge badge-elevated">Elevated</span>;
      case 'moderate':
        return <span className="badge badge-moderate">Moderate</span>;
      default:
        return <span className="badge badge-low">Healthy</span>;
    }
  };

  const getBorderGlow = (severity: SeverityLevel) => {
    switch (severity) {
      case 'critical':
        return 'var(--severity-critical-border)';
      case 'elevated':
        return 'var(--severity-elevated-border)';
      case 'moderate':
        return 'var(--severity-moderate-border)';
      default:
        return 'var(--border-subtle)';
    }
  };

  const cards = [
    {
      id: 'receivables',
      name: 'Receivables Health',
      icon: <Calendar size={18} color="var(--primary-accent)" />,
      severity: metrics.receivables_health.severity,
      primaryMetric: `${metrics.receivables_health.dso_proxy ?? '--'} days`,
      primaryLabel: 'Simplified DSO Proxy',
      secondaryMetric: `+${metrics.receivables_health.dso_delta_90d ?? 0}d`,
      secondaryLabel: '90-Day Delta',
      notes: metrics.receivables_health.formula_notes || 'Simplified prototype proxy: (AR / Revenue) * 365',
      extra: `Past 90d Aging: ${metrics.receivables_health.aging_buckets_pct?.ar_90_plus ?? 0}%`,
    },
    {
      id: 'payment',
      name: 'Payment Behavior',
      icon: <Users size={18} color="#818cf8" />,
      severity: metrics.payment_behavior.severity,
      primaryMetric: `${metrics.payment_behavior.deterioration_score} / 100`,
      primaryLabel: 'Deterioration Score',
      secondaryMetric: `${metrics.payment_behavior.late_bucket_pct}%`,
      secondaryLabel: 'Late Bucket (>60d)',
      notes: metrics.payment_behavior.notes || 'Tracks customer payment timing friction.',
      extra: 'Past-due collection transition index',
    },
    {
      id: 'supplier',
      name: 'Supplier Concentration',
      icon: <Building2 size={18} color="#f59e0b" />,
      severity: metrics.supplier_concentration.severity,
      primaryMetric: `${metrics.supplier_concentration.max_supplier_share_pct}%`,
      primaryLabel: 'Top Vendor Share',
      secondaryMetric: `${Math.round(metrics.supplier_concentration.hhi)}`,
      secondaryLabel: 'Payables HHI Index',
      notes: metrics.supplier_concentration.notes || 'HHI concentration on payables; exposure flagged if dominant vendor > 50%.',
      extra: metrics.supplier_concentration.is_exposed ? 'High Exposure Exposure Flagged' : 'Diversified Supplier Base',
    },
    {
      id: 'inventory',
      name: 'Inventory Efficiency',
      icon: <Package size={18} color="#10b981" />,
      severity: metrics.inventory_efficiency.severity,
      primaryMetric: `${metrics.inventory_efficiency.dio_days ?? '--'} days`,
      primaryLabel: 'Days Inventory Out (DIO)',
      secondaryMetric: `${metrics.inventory_efficiency.turnover_ratio ?? '--'}x`,
      secondaryLabel: 'Inventory Turnover',
      notes: metrics.inventory_efficiency.notes || 'Prototype formula: (Inventory / COGS) * 365',
      extra: 'Holding duration vs sales velocity',
    },
    {
      id: 'expense',
      name: 'Expense Anomalies',
      icon: <TrendingUp size={18} color="#ec4899" />,
      severity: metrics.expense_anomalies.severity,
      primaryMetric: `${metrics.expense_anomalies.anomaly_z_score > 0 ? '+' : ''}${metrics.expense_anomalies.anomaly_z_score}σ`,
      primaryLabel: 'Non-Core Z-Score',
      secondaryMetric: metrics.expense_anomalies.is_anomaly ? 'ANOMALY' : 'NORMAL',
      secondaryLabel: 'Variance Status',
      notes: metrics.expense_anomalies.notes || 'Statistical Z-score versus trailing historical baseline.',
      extra: `Baseline Mean: $${metrics.expense_anomalies.baseline_mean?.toLocaleString() ?? 'N/A'}`,
    },
    {
      id: 'cashflow',
      name: 'Cash-Flow Efficiency',
      icon: <DollarSign size={18} color="#38bdf8" />,
      severity: metrics.cash_flow_efficiency.severity,
      primaryMetric: `${metrics.cash_flow_efficiency.ccc_days} days`,
      primaryLabel: 'Cash Conversion Cycle (CCC)',
      secondaryMetric: `${metrics.cash_flow_efficiency.ocf_ni_divergence_score}`,
      secondaryLabel: 'OCF / NI Divergence',
      notes: 'CCC = DSO + DIO - DPO. High divergence indicates accounting profits without cash collections.',
      extra: `DPO: ${metrics.cash_flow_efficiency.dpo_days}d`,
    },
  ];

  return (
    <div className="glass-panel" style={{ padding: '24px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '18px' }}>
        <div>
          <h2 style={{ fontSize: '1.1rem', color: '#ffffff', letterSpacing: '-0.01em' }}>
            Multi-Signal Stress Heatmap
          </h2>
          <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
            Evaluated deterministically across 6 core operational dimensions
          </p>
        </div>
        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
          6 of 6 Signals Active
        </span>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
        gap: '14px',
      }}>
        {cards.map((c) => (
          <div
            key={c.id}
            onClick={() => setSelectedSignal(selectedSignal === c.id ? null : c.id)}
            className="glass-card-interactive"
            style={{
              background: 'rgba(14, 18, 29, 0.65)',
              border: `1px solid ${getBorderGlow(c.severity)}`,
              borderRadius: '12px',
              padding: '16px',
              transition: 'all 0.2s ease',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                {c.icon}
                <span style={{ fontSize: '0.9rem', fontWeight: 600, color: '#ffffff' }}>
                  {c.name}
                </span>
              </div>
              {getSeverityBadge(c.severity)}
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px', margin: '10px 0' }}>
              <div>
                <div style={{ fontSize: '1.25rem', fontWeight: 700, color: '#ffffff', fontFamily: 'var(--font-mono)' }}>
                  {c.primaryMetric}
                </div>
                <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                  {c.primaryLabel}
                </div>
              </div>
              <div>
                <div style={{ fontSize: '1.1rem', fontWeight: 600, color: 'var(--text-secondary)', fontFamily: 'var(--font-mono)' }}>
                  {c.secondaryMetric}
                </div>
                <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                  {c.secondaryLabel}
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', fontSize: '0.72rem', color: 'var(--text-muted)', paddingTop: '8px', borderTop: '1px solid var(--border-subtle)' }}>
              <span>{c.extra}</span>
              <ChevronRight size={14} />
            </div>

            {selectedSignal === c.id && (
              <div style={{ marginTop: '10px', padding: '8px', background: 'rgba(0,0,0,0.4)', borderRadius: '8px', fontSize: '0.72rem', color: 'var(--text-secondary)' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '4px', color: 'var(--primary-accent)', marginBottom: '3px' }}>
                  <AlertCircle size={12} />
                  <strong>Analytical Context:</strong>
                </div>
                {c.notes}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
